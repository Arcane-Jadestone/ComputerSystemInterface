#ifndef _Inits_h
#define _Inits_h

//Initialization prototypes
void PortD_Init(void);
void PortE_Init(void);


#endif
