#ifndef __LAB7_H__
#define __LAB7_H__

void InitConsole(void);
unsigned char myGetChar(void);

#endif
