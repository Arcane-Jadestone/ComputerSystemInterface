#ifndef _SysTick_h
#define _SysTick_h

void SysTick_Init(void);
void SysTick_Init_Interrupts(void);
void SysTick_Delay2s_16MHz(void);
void SysTick_Delay2s_50MHz(void);

#endif
