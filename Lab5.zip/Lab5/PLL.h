#ifndef _PLL_h
#define _PLL_h

void PLL_Init(void);

#endif
