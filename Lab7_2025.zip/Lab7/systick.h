#ifndef __SYSTICK_H__
#define __SYSTICK_H__

void SysTick_Init(void);
void Delay_100ms(void);

#endif
